<template>
   <tr>
     <td>
       <input type="text" v-model="editForm.student_name" class="form-control" v-if="edit">
       <span v-else>{{student.student_name}}</span>

     </td>

      <td>
       <input type="text" v-model="editForm.student_email" class="form-control"   v-if="edit">
       <span v-else>{{student.student_email}}</span>

     </td>


      <td>
       <textarea rows="5" cols="30" v-model="editForm.student_description" class="form-control" v-if="edit"></textarea>
       <span v-else>{{student.student_description}}</span>

     </td>










  
    <td>

   <button type="button" v-on:click="editStudent" class="btn btn-info btn-xs" v-if="!edit">Edit</button>

     <button type="button" v-on:click="cancelStudent" class="btn btn-warning btn-xs" v-if="edit">Cancel</button>


  <button type="button" v-on:click="updateStudent(student,editForm)" class="btn btn-primary btn-xs" v-if="edit">Update</button>

    <button type="button" v-on:click="$emit('delete-student',student)" class="btn btn-danger btn-xs" v-if="!edit">Delete</button>

    </td>

   </tr>



</template>

<script>
  export default{
    props:['student'],
    data(){
      return{
      edit:false,
      editForm:{
        student_name:'',
        student_email:'',
        student_description:''
         }
     
       }

      },


      methods:{
            editStudent(){
         this.edit=true;
         this.editForm.student_name=this.student.student_name;
         this.editForm.student_email=this.student.student_email;
          this.editForm.student_description=this.student.student_description;
        },

   cancelStudent(){
     this.edit=false;
     this.editForm.student_name='';
     this.editForm.student_email='';
     this.editForm.student_description='';
     },

       updateStudent(oldStudent,newStudent){
     this.$http.patch("/student/"+ oldStudent.id, newStudent).then( response => {
         this.$emit('update-student');
         this.cancelStudent();
         console.log(response.data);
     });
   }



   






   }


      
    
    

  }

</script>