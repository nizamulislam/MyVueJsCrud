

<template>

    <div>
      <form v-on:submit.prevent="createStudent" method="post" class="">
             
            

             <div v-bind:class="{'form-group':true,'has-error':errors.student_name}">
        
        <label>Name</label>
       
            <input type="text" v-model="student.student_name" class="form-control">

            <span class="help-block" v-for="error in errors.student_name" v-text="error"></span>
     
           </div>




  <div v-bind:class="{'form-group':true,'has-error':errors.student_email}">
        
        <label>Email</label>
       
            <input type="text" v-model="student.student_email" class="form-control">
         <span class="help-block" v-for="error in errors.student_email" v-text="error"></span>
     
          
           </div>




            <div v-bind:class="{'form-group':true,'has-error':errors.student_description}">
        
  
        <label>Description</label>
       
            <textarea rows="5" cols="40" v-model="student.student_description" class="form-control"></textarea>

            <span class="help-block" v-for="error in errors.student_description" v-text="error"></span>
     
           </div>



                <div class="form-group">
  
       
            <input type="submit"  class="btn btn-success" value="Save">
     
           </div>

         




      </form>














      
   

   <table class="table table-bordered">
         <thead>
           <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Description</th>
            <th>Action</th>

           </tr>



         </thead>


         <tbody>
       


           <student v-for="student in students"f v-bind:student="student" v-on:delete-student="deleteStudent" v-on:update-student="fetchStudent"></student>



         </tbody>

   </table>
   </div>
</template>

<script>
import student from './Student.vue';
    export default {
         data(){
            return {
              students: [],
              errors:[],
              student:{
                 student_name:'',
                 student_email:'',
                 student_description:''
              }
            }
         },

         components:{ student },

         created(){
           this.fetchStudent();
         },

         methods:{
            fetchStudent(){
                this.$http.get("student").then( response =>{
                     this.students = response.data.students
                }); 
            },

            createStudent(){
              this.$http.post("/student",this.student).then( response =>{
        
                   this.students.push(response.data.student);
                   this.student={student_name:'',student_email:'',student_description:''};

                   if(this.errors)
                   {
                      this.errors=[];
                   }

              },response =>{
                   this.errors=response.data.errors;
              });
            },

             deleteStudent(student){
            this.$http.delete("/student/"+ student.id).then(response => {
             let index = this.students.indexOf(student);
             this.students.splice(index,1);
             console.log(response.data);
            });
        }







         }
    }
</script>
